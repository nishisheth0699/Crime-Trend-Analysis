const express = require('express');
const app = express();
const sql = require('mssql');

const cors = require('cors');
app.use(cors({
  origin: '*'
}));

// create connection to database
const config = {
  server: 'localhost',
  database: 'Project',
  user: 'SA',
  password: '{Swapnil@0926}',
  options: {
    encrypt: false,
    enableArithAbort: true
  }
};

// connect to database
sql.connect(config, (err) => {
  if (err) {
    console.error('Error connecting to database: ', err);
    return;
  }
  console.log('Connected to database');
});

// handle GET request to retrieve all data from Crime_Report table
app.get('/crime-report', (req, res) => {
  const query = `
    SELECT 
      Report_ID,
      Report_Date,
      Report_Description,
      Officer_ID,
      Victim_ID,
      Crime_ID,
      Incident_ID
    FROM 
      Crime_Report
  `;
  sql.query(query, (error, results, fields) => {
    if (error) throw error;
    res.send(results.recordset);
  });
})
//post
// app.post("/crime-report", (req,res)=> {
//     const query = "INSERT INTO Crime_Report (`Report_ID`, `Report_Date`, `Report_Description`,`Officer_ID`,`Victim_ID`,`Crime_ID`,`Incident_ID`) VALUES(?,?,?,?,?,?,?)"
//     const values = ["a", "b", "c", "d", "e", "f", "g"] 

//     sql.query(query, values, (err, data)=>{
//       if (err) return res.json(err);
//       return res.json(data)
//     })
    
// })




var requestOptions = {
    method: 'POST',
    redirect: 'follow'
  };
  
  fetch("http://localhost:1013/crime-report", requestOptions)
    .then(response => response.text())
    .then(result => console.log(result))
    .catch(error => console.log('error', error));

// handle DELETE request to delete a crime report with a given report ID
// app.delete('/crime-report/:Report_ID', (req, res) => {
//   const Report_ID = req.params.Report_ID;
//   const query = `
//     DELETE FROM Crime_Report
//     WHERE Report_ID = ${Report_ID}
//   `;
//   sql.query(query, (error, results, fields) => {
//     if (error) throw error;
//     res.send(`Crime report with ID ${Report_ID} deleted`);
//   });
// });

// start server
app.listen(1013, () => {
  console.log('Server started on port 3008');
});