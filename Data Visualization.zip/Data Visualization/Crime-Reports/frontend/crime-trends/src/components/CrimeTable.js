import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper
} from '@material-ui/core';

const useStyles = makeStyles({
  table: {
    minWidth: 300, // Set a smaller minWidth value to make the table narrower
    maxWidth: 800,
    },
});

function arrayBufferToBase64(buffer) {
  var binary = '';
  var bytes = [].slice.call(new Uint8Array(buffer));
  bytes.forEach((b) => binary += String.fromCharCode(b));
  return window.btoa(binary);
};

function CrimeTable(props) {
  const classes = useStyles(); // initialize the Material UI styles
  const rows = props.data.map((crime) => {
    console.log("crime",crime)
    return (
    <TableRow key={crime.Report_ID}>
      <TableCell component='th' scope='row'>
        {crime.Report_ID}
      </TableCell>
      <TableCell align='right'>{crime.Report_Date}</TableCell>
      <TableCell align='right'>{arrayBufferToBase64(crime.Report_Description.data)}</TableCell>
      <TableCell align='right'>{crime.Officer_ID}</TableCell>
      <TableCell align='right'>{crime.Victim_ID}</TableCell>
      <TableCell align='right'>{crime.Crime_ID}</TableCell>
      <TableCell align='right'>{crime.Incident_ID}</TableCell>
    </TableRow>
  )
});

  return (
    <TableContainer component={Paper} style={{ overflowX: 'auto' }}>
      <Table className="my-custom-table" aria-label='simple table'>
        <TableHead>
          <TableRow>
            <TableCell style={{ textAlign: 'center' }}>Report ID</TableCell>
            <TableCell style={{ textAlign: 'center' }} align='right'>Report Date</TableCell>
            <TableCell style={{ textAlign: 'center' }} align='right'>Report Description</TableCell>
            <TableCell style={{ textAlign: 'center' }} align='right'>Officer ID</TableCell>
            <TableCell style={{ textAlign: 'center' }} align='right'>Victim ID</TableCell>
            <TableCell style={{ textAlign: 'center' }} align='right'>Crime ID</TableCell>
            <TableCell style={{ textAlign: 'center' }} align='right'>Incident ID</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>{rows}</TableBody>
      </Table>
    </TableContainer>
  );
}

export default CrimeTable;
