import React, { useState, useEffect } from "react";
import "./App.css";
import CrimeTable from "./components/CrimeTable";
import axios from "axios";

function App() {
  const [crimeData, setCrimeData] = useState([]);
  const [showTable, setShowTable] = useState(false);

  useEffect(() => {
    async function fetchData() {
      var requestOptions = {
        method: "GET",
        redirect: "follow",
      };

      fetch("http://localhost:1011/crime-report", requestOptions)
        .then((response) => response.json())
        .then((result) => {
          setCrimeData(result);
        })
        .catch((error) => console.log("error", error));
  
      }
    fetchData();
  }, []);

  return (
    <>

    <div className="title">
      <h1>Crime Trends in Massachusetts</h1>
    </div>
      <div className="crime-table">
        <h1>Crime Report Table</h1>
        {showTable && <CrimeTable data={crimeData} />}
        <button className="my-button" onClick={() => setShowTable(!showTable)}>
          {showTable ? "Hide Table" : "Show Table"}
        </button>
      </div>
      <div className="powerbi">
        <h1>PowerBi Report</h1>
        <img src={require('./bi.jpg')} className="image"/>     
       </div>
    </>
  );
}

export default App;
